<?php
include "connection.php";
if (isset($_POST)) {

	$title = $_POST['title'];
	$textinfo = $_POST['textinfo'];
	$sql = "INSERT INTO userpost(title,data_description) VALUES('".$title."','".$textinfo."')";
	$result = mysqli_query($conn,$sql);
	if ($result) {
		echo "You have been successfully inserted";
	}
}
?>