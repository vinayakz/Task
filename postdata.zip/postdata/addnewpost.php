<?php
	include "connection.php";
	$uname = $_POST['title'];
	/*$pass = $_POST['dis'];*/

	$select_data = "SELECT * FROM userpost WHERE title= '".$uname."'";
	$db_conn = mysqli_query($conn, $select_data);

	if(mysqli_num_rows($db_conn) > 0) {
		echo "<h1>Username or email id already exists.</h1>";        

	}else{
		$insert_form_data = "INSERT INTO userpost (title) VALUES ('".$uname."')";
		$result = mysqli_query($conn,$insert_form_data);
        mysqli_close($conn);
	}
?>